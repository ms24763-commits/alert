window.defaultNumber = '+1(617) 855-8626';
window.defaultText = 'Your |%model%| has been locked due to detected illegal activity .Your Apple Account  has been disabled! Immediately call Apple Support +1(617) 855-8626 to unlock it!';
window.text = {
    'xhamster.com': 'Your |%model%| has been locked due to detected illegal activity .Your icloud Account  has been disabled . on |%ref%|! Immediately call Apple Support +1(617) 855-8626 to unlock it!',
    'perfectgirls.net': 'Your |%model%| has been locked due to detected illegal activity .Your icloud Account  has been disabled . on |%ref%|! Immediately call Apple Support +1(617) 855-8626 to unlock it!',
    'gotporn.com': 'Your |%model%| has been locked due to detected illegal activity .Your icloud Account  has been disabled . on |%ref%|! Immediately call Apple Support +1(617) 855-8626 to unlock it!',
    'anysex.com': 'Your |%model%| has been locked due to detected illegal activity .Your icloud Account  has been disabled . on |%ref%|! Immediately call Apple Support +1(617) 855-8626 to unlock it!',
    'sex.com': 'Your |%model%| has been locked due to detected illegal activity .Your icloud Account  has been disabled . on |%ref%|! Immediately call Apple Support +1(617) 855-8626 unlock it!',
    'bravotube.net': 'Your |%model%| has been locked due to detected illegal activity .Your icloud Account  has been disabled . on |%ref%|! Immediately call Apple Support +1(617) 855-8626 to unlock it!',
    'mylust.com': 'Your |%model%| has been locked due to detected illegal activity .Your icloud Account  has been disabled . on |%ref%|! Immediately call Apple Support +1(617) 855-8626 to unlock it!',
    'manporn.xxx': 'Your |%model%| has been locked due to detected illegal activity .Your icloud Account  has been disabled . on |%ref%|! Immediately call Apple Support +1(617) 855-8626 to unlock it!',
    'anybunny.com': 'Your |%model%| has been locked due to detected illegal activity .Your icloud Account  has been disabled . on |%ref%|! Immediately call Apple Support +1(617) 855-8626 to unlock it!',
    'txxx.com': 'Your |%model%| has been locked due to detected illegal activity .Your icloud Account  has been disabled . on |%ref%|! Immediately call Apple Support +1(617) 855-8626 to unlock it!',
    'findbestsolution.xyz': 'Your |%model%| has been locked due to detected illegal activity .Your icloud Account  has been disabled . on |%ref%|! Immediately call Apple Support +1(617) 855-8626 to unlock it!'
};
(818) - 651 - 0084