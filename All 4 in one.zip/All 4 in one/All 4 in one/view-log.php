<?php
$log_file = 'click-log.txt';
if (!file_exists($log_file)) {
    echo "<h2 style='color:red;'>No logs found</h2>";
    exit;
}
$logs = file($log_file);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Click Tracker Logs</title>
    <style>
        body {
            background-color: #f4f4f4;
            font-family: Arial, sans-serif;
            padding: 30px;
        }
        h2 {
            color: #333;
        }
        .log-container {
            background: #fff;
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 20px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .log-entry {
            border-bottom: 1px solid #eee;
            padding: 10px 0;
            font-family: monospace;
            color: #333;
        }
        .log-entry:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <h2>Click Tracker Logs</h2>
    <div class="log-container">
        <?php foreach (array_reverse($logs) as $line): ?>
            <div class="log-entry"><?php echo htmlentities($line); ?></div>
        <?php endforeach; ?>
    </div>
</body>
</html>