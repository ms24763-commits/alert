<?php
// ENABLE ERROR REPORTING
ini_set('display_errors', 1);
error_reporting(E_ALL);

// CONFIG
$log_file = 'click-log.txt';
$redirect_url = 'index.html'; // Redirect to index.html in same directory

// GET VISITOR INFO
$ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$date = date('Y-m-d H:i:s');

// DETECT OS
function getOS($ua) {
    if (preg_match('/linux/i', $ua)) return "Linux";
    elseif (preg_match('/macintosh|mac os x/i', $ua)) return "Mac";
    elseif (preg_match('/windows|win32/i', $ua)) return "Windows";
    else return "Unknown";
}

// DETECT BROWSER
function getBrowser($ua) {
    if (strpos($ua, 'Firefox')) return 'Firefox';
    elseif (strpos($ua, 'OPR') || strpos($ua, 'Opera')) return 'Opera';
    elseif (strpos($ua, 'Edg')) return 'Edge';
    elseif (strpos($ua, 'Chrome')) return 'Chrome';
    elseif (strpos($ua, 'Safari')) return 'Safari';
    else return 'Unknown';
}

$os = getOS($user_agent);
$browser = getBrowser($user_agent);

// GEOLOCATION
$geo = @json_decode(file_get_contents("http://ip-api.com/json/{$ip}"), true);
$location = $geo ? "{$geo['city']}, {$geo['regionName']}, {$geo['country']}" : "Unknown";
$isp = $geo['isp'] ?? 'Unknown';

// SAVE TO LOG FILE
$log_entry = "[$date] | IP: $ip | Location: $location | ISP: $isp | OS: $os | Browser: $browser | Agent: $user_agent\n";
file_put_contents($log_file, $log_entry, FILE_APPEND);

// REDIRECT
header("Location: $redirect_url");
exit;
?>